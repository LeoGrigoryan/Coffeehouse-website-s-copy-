import { useEffect, useRef, useState } from 'react';
import './App.css';
import { Routes, Route } from 'react-router-dom';
import AllOne from './components/Home/AllOne';
import Context from './Context';

function App() {

  const [scrollBeh, setScrollBeh] = useState(-1);

  const [sideOpener, setSideOpener] = useState(false);
  const [size, setSize] = useState(0);
  const [opac, setOpac] = useState(0);

  const hRef = useRef()
  useEffect(() => {
    window.onload = () => {
      window.history.scrollRestoration = 'manual';
      window.scrollTo(0, 0)
      document.body.style.height = `${hRef.current.offsetHeight}px`;
    }
    window.onscroll = (a) => {
      a = window.scrollY;
      setScrollBeh(-a * .99)
    }
  })

  const bus = {
    sideOpener, setSideOpener,
    size, setSize,
    opac, setOpac,
    scrollBeh
  }

  return (
    <Context.Provider value={bus}>
      <div className="App" ref={hRef} style={{ top: scrollBeh + 'px' }}>
        <Routes>
          <Route path='/' element={<AllOne />}></Route>
        </Routes>
      </div>
    </Context.Provider>
  );
}

export default App;
