import React from 'react';
import './Location.css';
import { FaHeart } from 'react-icons/fa6';
import pic from '../../../Pictures/map.png';
import { motion, useInView, useAnimation } from 'framer-motion';
import { useRef, useEffect } from 'react';

export default function Locatons() {

    const picRef = useRef();

    const isView = useInView(picRef, { once: true })
    const motImg = useAnimation();
    useEffect(() => {
        if (isView) {
            motImg.start('end');
        }
    }, [isView, motImg])
    
    const refOne = useRef();

    const isViewOne = useInView(refOne, { once: true })
    const motOne = useAnimation();
    useEffect(() => {
        if (isViewOne) {
            motOne.start('go');
        }
    }, [isViewOne, motOne])
    
    const refTwo = useRef();

    const isViewTwo = useInView(refTwo, { once: true })
    const motTwo = useAnimation();
    useEffect(() => {
        if (isViewTwo) {
            motTwo.start('go');
        }
    }, [isViewTwo, motTwo])
    
    const refThree = useRef();

    const isViewThree = useInView(refThree, { once: true })
    const motThree = useAnimation();
    useEffect(() => {
        if (isViewOne) {
            motThree.start('go');
        }
    }, [isViewThree, motThree])


    const varin = {
        stay: {opacity: 0, y: 150},
        go: {opacity: 1, y: 0}
    }

    return (
        <section className='loc'>
            <div className="dev-parts">
                <motion.div ref={picRef} variants={{ start: { opacity: 0, scale: .8 }, end: { opacity: 1, scale: 1 } }} transition={{ duration: 1, delay: .4 }} initial='start' animate={motImg}>
                    <img src={pic} />
                </motion.div>
            </div>
            <div className="dev-parts">
                <div className="text-of-loc">
                    <motion.div ref={refOne} variants={varin} initial='stay' animate={motOne} transition={{duration: .8, delay: 0}}>
                        <div className="contain">
                            <h2 className="m-text">
                                Արի
                                <br />
                                հետևից
                            </h2>
                            <div className="heart">
                                <FaHeart />
                            </div>
                            <h2 className="m-text control-h">
                                սիրո
                            </h2>
                        </div>
                    </motion.div>
                    <motion.div ref={refTwo} variants={varin} initial='stay' animate={motTwo} transition={{duration: .8, delay: .15}}>
                        <p className='c-text'>
                            8 տարի… 7 քաղաք
                            <br />
                            Արդեն 42 մասնաճյուղ ամբողջ Հայաստանում:
                            <br />
                            Գտիր քեզ ամենամոտը և ի վերջո…
                        </p>
                    </motion.div>
                    <motion.div ref={refThree} variants={varin} initial='stay' animate={motThree} transition={{duration: .8, delay: .3}}>
                        <button className='main-but'>
                            <div className="cover-but-two">
                                {'սրճե՞նք :)'}
                            </div>
                        </button>
                    </motion.div>
                </div>
            </div>
        </section >
    )
}
