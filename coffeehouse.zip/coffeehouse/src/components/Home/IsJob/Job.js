import React, { useEffect, useRef } from 'react';
import pic from '../../../Pictures/lastPicture.png';
import './Job.css';
import { motion, useInView, useAnimation } from 'framer-motion';

export default function Job() {

    const PicRef = useRef();
    const motPic = useAnimation();
    const isView = useInView(PicRef, { once: true });

    useEffect(() => {

        if (isView) {
            motPic.start('end')
        } else {
            motPic.start('start')
        }

    }, [isView, motPic])

    const oneRef = useRef();
    const motOne = useAnimation();
    const isViewOne = useInView(PicRef, { once: true });

    useEffect(() => {

        if (isViewOne) {
            motOne.start('end')
        } else {
            motOne.start('start')
        }

    }, [isViewOne, motOne])

    const twoRef = useRef();
    const motTwo = useAnimation();
    const isViewTwo = useInView(PicRef, { once: true });

    useEffect(() => {

        if (isViewTwo) {
            motTwo.start('end')
        } else {
            motTwo.start('start')
        }

    }, [isViewTwo, motTwo])

    const ThreRef = useRef();
    const motThre = useAnimation();
    const isViewThre = useInView(PicRef, { once: true });

    useEffect(() => {

        if (isViewThre) {
            motThre.start('end')
        } else {
            motThre.start('start')
        }

    }, [isViewThre, motThre])


    const vars = {
        start: { opacity: .4, y: 150 },
        end: { opacity: 1, y: 0 },
    }

    return (
        <section className='job'>
            <div className="item">
                <motion.div ref={PicRef} variants={{
                    start: { rotate: 0 },
                    end: { rotate: -15 }
                }} transition={{ duration: .7, delay: .2 }} initial='start' animate={motPic}>
                    <img src={pic} />
                </motion.div>
            </div>
            <div className="item">
                <motion.div ref={oneRef} variants={vars} transition={{ duration: .8, delay: 0 }} initial='start' animate={motOne}>
                    <h2 className='m-text'>
                        Միացիր մեր
                        թիմին
                    </h2>
                </motion.div>
                <motion.div ref={twoRef} variants={vars} transition={{ duration: .8, delay: .15 }} initial='start' animate={motTwo}>
                    <p className='c-text'>
                        Օրեցօր զարգացող և ընդլայնվող մեր ընկերությունում քեզ
                        <br />
                        համար #գործկա։
                        <br />
                        <br />
                        <br />
                        <br />
                        Սիրով սպասում ենք
                    </p>
                </motion.div>
                <motion.div ref={ThreRef} variants={vars} transition={{ duration: .8, delay: .3 }} initial='start' animate={motThre}>
                    <button className='main-but'>
                        <div className="cover-but-two">
                            {'դիմիր հիմա'}
                        </div>
                    </button>
                </motion.div>
            </div>
        </section>
    )
}
