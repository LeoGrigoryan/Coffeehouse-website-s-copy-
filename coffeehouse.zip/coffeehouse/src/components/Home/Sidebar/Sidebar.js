import React, { useState } from 'react';
import './Sidebar.css';
import Context from '../../../Context';
import { useContext } from 'react';
import { Link } from 'react-router-dom';
import { FaInstagram, FaTelegram, FaFacebookF, FaTiktok, FaLinkedinIn } from 'react-icons/fa6';

export default function Sidebar() {

    const mail = useContext(Context);

    const arr = [
        {
            logo: <FaTelegram />,
            link: '',
            name: 'Telegram'
        },
        {
            logo: <FaInstagram />,
            link: '',
            name: 'Instagram'
        },
        {
            logo: <FaFacebookF />,
            link: '',
            name: 'Facebook'
        },
        {
            logo: <FaTiktok />,
            link: '',
            name: 'TikTok'
        },
        {
            logo: <FaLinkedinIn />,
            link: '',
            name: 'Linkedin'
        },
    ]

    return (
        <div className="coverBlock" style={{ display: mail.sideOpener ? 'flex' : 'none' }}>
            <div className="sizeGiver">
                <aside style={{ width: `${mail.size}%`, height: `${mail.size}%` }}>
                    <div className="all-of-aside" style={{ opacity: mail.opac }}>
                        <div className="top">
                            <li>ՀԱՅ</li>
                            <li>РУС</li>
                            <li>ENG</li>
                        </div>
                        <div className="links-parent">
                            <ul>
                                <li>
                                    <Link to="/" className='links'>
                                        Մեր տեսականին
                                    </Link>
                                </li>
                                <li>
                                    <Link to="/" className='links'>
                                        Մասնաճյուղեր
                                    </Link>
                                </li>
                                <li>
                                    <Link to="/" className='links'>
                                        Մեր մասին
                                    </Link>
                                </li>
                                <li>
                                    <Link to="/" className='links'>
                                        Կարիերա
                                    </Link>
                                </li>
                            </ul>
                            <ul>
                                <li>
                                    <Link to='/' className='links'>
                                        Նորություններ
                                    </Link>
                                </li>

                                <li>
                                    <Link to='/' className='links'>
                                        Կապ մեզ հետ
                                    </Link>
                                </li>
                                <div className="container-for-soc">
                                    <div className="contain-s">
                                        {
                                            arr.map((item, index) => (
                                                <a href="#" className='links' key={index}>{item.logo}
                                                    <span>
                                                        {item.name}
                                                    </span>
                                                </a>
                                            ))
                                        }
                                    </div>
                                </div>
                            </ul>
                        </div>
                    </div>
                </aside>
            </div>
        </div>

    )
}
