import React from 'react';
import logo from '../../../Pictures/main-logo.svg';
import { FaWhatsapp } from 'react-icons/fa6';
import { FaInstagram, FaTelegram, FaFacebookF, FaTiktok, FaLinkedinIn } from 'react-icons/fa6';
import { FaTelegramPlane } from 'react-icons/fa';
import './Footer.css';
import { FaHeart } from 'react-icons/fa6';


export default function Footer() {
    const arr = ['Մեր մասին', '-', 'Մեր տեսականին', '-', 'Մասնաճյուղեր', '-', 'Նորություններ', '-', 'Կապ մեզ հետ', '-', 'Կարիերա']
    return (
        <footer className='w-100 d-flex flex-column align-items-center '>
            <div className="footer-form w-100 d-flex flex-column align-items-center">
                <div className="top-part w-100 d-flex">
                    <img src={logo} />
                    <div className="links-of-footer">
                        <ul className='g-5 d-flex align-items-center text-white'>
                            {
                                arr.map((item, index) => (
                                    <li key={index}>{item}</li>
                                ))
                            }
                        </ul>
                    </div>
                </div>
                <div className="r-0 position-relative  foot-soc d-flex justify-content-between g-5 fs-5 fw-normal">
                    <div className="left-soc d-flex align-items-center g-5">
                        <a href="#">info@coffeehouse.am</a>
                        <a href="tel:+374 33 885855" className='d-flex align-items-center tel'>
                            <FaWhatsapp className='fs-4' />
                            +374 33 885855
                        </a>
                    </div>
                    <div className="right-soc d-flex g-5 fs-4">
                        <a href="#">
                            <FaTelegramPlane />
                        </a>
                        <a href="#">
                            <FaInstagram />
                        </a>
                        <a href="#">
                            <FaFacebookF />
                        </a>
                        <a href="#">
                            <FaTiktok />
                        </a>
                        <a href="#">
                            <FaLinkedinIn />
                        </a>
                    </div>
                </div>
            </div>
            <div className="animate-bor">
                <div className="cover-animate position-relative">
                    <div className="big position-absolute">
                        <ul className='d-flex align-items-center g-5 fs-5 fw-normal'>
                            <li className='text-white'>
                                Արի սիրո հետևից
                            </li>
                            <li>
                                <FaHeart className='text-danger' />
                            </li>
                            <li className='text-white'>
                                Արի սիրո հետևից
                            </li>
                            <li>
                                <FaHeart className='text-danger' />
                            </li>
                            <li className='text-white'>
                                Արի սիրո հետևից
                            </li>
                            <li>
                                <FaHeart className='text-danger' />
                            </li>
                            <li className='text-white'>
                                Արի սիրո հետևից
                            </li>
                            <li>
                                <FaHeart className='text-danger' />
                            </li>
                            <li className='text-white'>
                                Արի սիրո հետևից
                            </li>
                            <li>
                                <FaHeart className='text-danger' />
                            </li>
                            <li className='text-white'>
                                Արի սիրո հետևից
                            </li>
                            <li>
                                <FaHeart className='text-danger' />
                            </li>
                            <li className='text-white'>
                                Արի սիրո հետևից
                            </li>
                            <li>
                                <FaHeart className='text-danger' />
                            </li>
                            <li className='text-white'>
                                Արի սիրո հետևից
                            </li>
                            <li>
                                <FaHeart className='text-danger' />
                            </li>
                            <li className='text-white'>
                                Արի սիրո հետևից
                            </li>
                            <li>
                                <FaHeart className='text-danger' />
                            </li>
                            <li className='text-white'>
                                Արի սիրո հետևից
                            </li>
                            <li>
                                <FaHeart className='text-danger' />
                            </li>
                            <li className='text-white'>
                                Արի սիրո հետևից
                            </li>
                            <li>
                                <FaHeart className='text-danger' />
                            </li>
                            <li className='text-white'>
                                Արի սիրո հետևից
                            </li>
                            <li>
                                <FaHeart className='text-danger' />
                            </li>
                            <li className='text-white'>
                                Արի սիրո հետևից
                            </li>
                            <li>
                                <FaHeart className='text-danger' />
                            </li>
                            <li className='text-white'>
                                Արի սիրո հետևից
                            </li>
                            <li>
                                <FaHeart className='text-danger' />
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </footer>
    )
}
