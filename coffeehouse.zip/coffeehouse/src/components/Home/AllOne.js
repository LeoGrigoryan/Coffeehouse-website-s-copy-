import React from 'react';
import Header from './Header/Header';
import About from './About/About';
import Locatons from './Locations/Locatons';
import Info from './Information/Info';
import Job from './IsJob/Job';
import Footer from './Footer/Footer';

export default function AllOne() {
  return (
    <section className='one'>
      <Header />
      <About />
      <Locatons />
      <Info/>
      <Job/>
      <Footer/>
    </section>
  )
}
