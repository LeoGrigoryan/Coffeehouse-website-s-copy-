import { render } from '@testing-library/react';
import React, { useRef, useEffect } from 'react';
import { Canvas } from '@react-three/fiber';
import { BoxGeometry, MeshStandardMaterial } from 'three';
import Context from '../../../Context';
import { useContext } from 'react';
import { Cup } from './Scene';

function Box({ args, rot, pos }) {
    return (
        <mesh rotation={rot} position={pos}>
            <boxGeometry args={args} />
            <meshStandardMaterial color={'#f00'} />
        </mesh>
    )
}

export default function Model() {

    const mail = useContext(Context);


    // <mesh position={[0, 0, 0]} rotation={[0, mail.scrollBeh * .0045, 0]}>
    // <Box args={[.7, 6.3, .7]} rot={[0, 0, Math.PI / 150]} />
    // <Box args={[.8, 1.65, .7]} rot={[0, 0, Math.PI / 2]} pos={[1, 0, 0]} />
    // <Box args={[.7, 4.4, .7]} rot={[0, 0, Math.PI / -150]} pos={[1.6, 0, 0]} />
    // <Box args={[.7, 6.2, .7]} rot={[0, 0, Math.PI / -90]} pos={[2.5, 0, 0]} />
    // <Box args={[.7, 2.5, .7]} rot={[0, 0, Math.PI / 2.02]} pos={[1.67, 2.76, 0]} />
    // <Box args={[.635, 2.5, .7]} rot={[0, 0, Math.PI / 200]} pos={[.75, 1.86, 0]} />
    // <Box args={[.55, 2.5, .7]} rot={[0, 0, Math.PI / 200]} pos={[.8, -1.84, 0]} />
    // <Box args={[.5, 1.9, .7]} rot={[0, 0, Math.PI / 2.02]} pos={[1.67, -2.84, 0]} />
    // </mesh>

    const meshRef = useRef();

    useEffect(() => {
        if (meshRef.current) {
            meshRef.current.geometry.center();
        }
    }, []);

    return (
        <div className='model'>
            <Canvas camera={{ position: [0, 1, 8] }}>
                <directionalLight intensity={2} position={[100, 100, 100]} receiveShadow />
                <mesh  castShadow scale={4.5} position={[0, -1, 0]} rotation={[-window.scrollY * .000009, -window.scrollY * .0044, Math.PI / 5]}>
                    <Cup/>
                </mesh>
            </Canvas>
        </div>
    )
}
