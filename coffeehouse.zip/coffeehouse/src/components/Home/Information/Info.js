import React from 'react';
import './Info.css';
import Model from './Model';

export default function Info() {
    return (
        <section className='info'>
            <div className="all-sect">
                <div className="sticky-div">
                    <Model />
                </div>
            </div>
            <div className="item">
                <h2 className='m-text'>
                    42 մասնաճյուղ
                    <br />
                    Երևանում և
                    <br />
                    մարզերում
                </h2>
            </div>
            <div className="item">
                <h2 className='m-text'>
                    300 000 և ավել
                    <br />
                    մշտական
                    <br />
                    հաճախորդ
                </h2>
            </div>
            <div className="item">
                <h2 className='m-text'>
                    250 և ավել
                    <br />
                    երջանիկ
                    <br />
                    աշխատակից
                </h2>
            </div>
        </section>
    )
}
