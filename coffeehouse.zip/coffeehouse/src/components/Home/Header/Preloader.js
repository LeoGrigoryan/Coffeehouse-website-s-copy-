import React, { useEffect, useState } from 'react';
import logo from '../../../Pictures/main-logo.svg';
import { Link } from 'react-router-dom';

export default function Preloader() {
    const [isLoader, setIsLoader] = useState(true);

    useEffect(() => {
        const handleLoad = () => {
            setIsLoader(false);
        };

        window.addEventListener('load', handleLoad);

        return () => {
            window.removeEventListener('load', handleLoad);
        };
    }, []);

    return (
        <div className='preloader' style={{ left: !isLoader ? '11.5rem' : '50%', top: !isLoader ? '1%' : '50%' }}>
            <Link to='/' className='links'>
                <img src={logo} />
            </Link>
        </div>
    );
}
