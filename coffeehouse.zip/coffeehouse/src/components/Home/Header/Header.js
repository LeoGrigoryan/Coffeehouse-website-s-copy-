import React, { useRef, useState, useEffect } from 'react';
import Preloader from './Preloader';
import backPic from '../../../Pictures/main-bg.webp';
import Sidebar from '../Sidebar/Sidebar';
import Context from '../../../Context';
import { useContext } from 'react';
import './Header.css';
import { Link } from 'react-router-dom';

export default function Header() {

    const mail = useContext(Context);

    const [menucom, setMenucom] = useState(true);
    const [opac, setOpac] = useState(0);

    const [Thingsan, setThingsan] = useState([0, 0, 0]);
    const [gaper, setGaper] = useState([-.4, 0, .4]);
    const [forClick, setForClick] = useState(true);

    const [preShower, setPreShower] = useState(100);

    const [butShower, setButShower] = useState(30);
    const [butExistense, setButExistense] = useState('none');

    const [bg, setBg] = useState('#fff');
    const [cl, setCl] = useState('#181818');

    const [forControll, setForControll] = useState(false);

    const [trans, setTrans] = useState(1.1);

    const [cur, setCur] = useState(true);

    const [showStarter, setShowStarter] = useState(false);

    const clasAd = useRef();
    const forSide = useRef();
    const forScroll = useRef();

    const stl = {
        clipPath: showStarter ? 'polygon(0 0, 100% 0, 100% 100%, 0% 100%)' : 'polygon(100% 0, 100% 0, 100% 0, 100% 0)'
    };


    useEffect(() => {
        if (mail.sideOpener === false) {
            window.history.scrollRestoration = 'manual';
            window.scrollTo(0, forScroll.current.offsetHeight + 10)
        }else {
            return false;
        }
    }, [cur])


    useEffect(() => {
        setTimeout(() => {
            setMenucom(false)
            setShowStarter(!showStarter)
            setTimeout(() => {
                setPreShower(0)
                setTimeout(() => {
                    setButExistense('block')
                }, 750);
                setTimeout(() => {
                    setButShower(100)
                }, 800);
            }, 800);
            setTimeout(() => {
                setTrans(.3);
                setForControll(true);
            }, 1100);
        }, 1200);
        setTimeout(() => {
            setOpac(1);
            setTimeout(() => {
                clasAd.current.className = 'kikky';
            }, 2000);
        }, 1);
    }, [])


    const clickFun = () => {
        if (forControll) {
            if (forClick) {
                setThingsan([45, 45, -45])
                setGaper([0, 0, 0])
                setBg('#181818')
                setCl('#fff')
            } else {
                setThingsan([0, 0, 0])
                setGaper([-.4, 0, .4])
                setBg('#fff')
                setCl('#181818')
            }
            setForClick(!forClick)

            if (!mail.sideOpener) {
                setMenucom(true)
                mail.setSideOpener(true);
                document.body.style.overflow = 'hidden';
                setTimeout(() => {
                    mail.setSize(100)
                }, 1);
                setTimeout(() => {
                    mail.setOpac(1);
                }, 800);
            } else {
                mail.setOpac(0);
                setTimeout(() => {
                    document.body.style.overflow = 'visible';
                    mail.setSize(0)
                    setTimeout(() => {
                        setMenucom(false)
                        mail.setSideOpener(false);
                    }, 1000);
                }, 300);
            }
            setForControll(false);
            setTimeout(() => {
                setForControll(true);
            }, 1200);
        } else {
            return false;
        }
    }
    return (
        <header ref={forScroll}>
            <div className="header">
                <nav>
                    <ul style={{ left: menucom ? '100%' : '0', transition: trans + 's' }}>
                        <li>
                            <Link to='/' className='links'>
                                Մեր տեսականին
                            </Link>
                        </li>
                        <li>
                            <Link to='/' className='links'>
                                Մասնաճյուղեր
                            </Link>
                        </li>
                        <li>
                            <Link to='/' className='links'>
                                Մեր մասին
                            </Link>
                        </li>
                        <li>
                            <Link to='/' className='links'>
                                Կարիերա
                            </Link>
                        </li>
                    </ul>
                    <button style={{ opacity: opac, background: bg }} ref={clasAd} className='ok' onClick={() => clickFun()}>
                        {
                            Thingsan.map((item, index) => (
                                <span key={index} style={{ rotate: item + 'deg', translate: `0 ${gaper[index]}rem`, background: cl }} ></span>
                            ))
                        }
                    </button>
                </nav>
            </div>
            <Preloader />
            <main>
                <div className="wallpaper" style={stl}>
                    <img src={backPic} />
                </div>
                <div className="top-side">
                    <h1>
                        <span style={{ top: preShower + '%' }}>Սեր և Սուրճ</span>
                    </h1>
                    <h1>
                        <span style={{ top: preShower + '%' }}>Մեկ Բաժակում</span>
                    </h1>
                    <div className="sizeSeter">
                        <button onClick={() => setCur(!cur)} style={{ height: butShower + '%', display: butExistense }}><span>›</span></button>
                    </div>
                </div>
            </main>
            <Sidebar />
        </header>
    )
}
