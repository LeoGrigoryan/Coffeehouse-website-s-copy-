import React, { useEffect, useRef, useState } from 'react';
import './About.css';
import Context from '../../../Context';
import { useContext } from 'react';

import '../../../../node_modules/swiper/swiper.css';
import { Swiper, SwiperSlide } from 'swiper/react';

// npm i framer-motion

import { motion, useInView, useAnimation } from 'framer-motion';

import img1 from '../../../Slides/img1.png';
import img2 from '../../../Slides/img2.webp';
import img3 from '../../../Slides/img3.webp';

export default function About() {

    const mail = useContext(Context);
    const [perView, setPerView] = useState(2)


    const forOne = useRef();
    const forTwo = useRef();
    const forThree = useRef();

    const PicView = useInView(forOne, { once: true });
    const motPic = useAnimation();
    useEffect(() => {
        if (PicView) {
            motPic.start('opac')
        }
    }, [PicView, motPic])


    const inViewOne = useInView(forOne, { once: true })
    const inViewTwo = useInView(forTwo, { once: true })
    const inViewThree = useInView(forThree, { once: true })

    const motOne = useAnimation()
    const motTwo = useAnimation()
    const motThree = useAnimation()

    useEffect(() => {
        if (inViewOne) {
            motOne.start('end');
        }   
    }, [inViewOne, motOne])

    useEffect(() => {
        if (inViewTwo) {
            motTwo.start('end');
        }   
    }, [inViewTwo, motTwo])

    useEffect(() => {
        if (inViewThree) {
            motThree.start('end');
        }   
    }, [inViewThree, motThree])

    const objVariants = {
        start: { y: 150, opacity: 0 },
        end: { y: 0, opacity: 1 }
    }

    const braker = {
        1780: {
            slidesPerView: 2,
            spaceBetween: 0
        },
        1470: {
            slidesPerView: 1.5,
            spaceBetween: -100
        },
        1100: {
            slidesPerView: 1.5,
            spaceBetween: 100
        },
        1000: {
            slidesPerView: 1.5,
            spaceBetween: 200
        },
        900: {
            slidesPerView: 1,
            spaceBetween: 300
        },
        800: {
            slidesPerView: 1,
            spaceBetween: 500
        },
        700: {
            slidesPerView: 2,
            spaceBetween: 50
        },
    }

    return (
        <section className='about'>
            <div className="container-for-about">
                <div className="text-of-about">
                    <motion.div variants={objVariants} transition={{ duration: .9, delay: 0 }} initial='start' animate={motOne} ref={forOne}>
                        <h2 className='m-text'>Մեր մասին</h2>
                    </motion.div>
                    <motion.div variants={objVariants} transition={{ duration: .9, delay: .1 }} initial='start' animate={motTwo} ref={forTwo}>
                        <p className='c-text'>
                            Թե ինչպես 2 ուսանող հիմնեցին սուրճի վաճառքի առաջատար
                            <br />
                            և ամենամեծ ցանցը Հայաստանում...
                        </p>
                    </motion.div>
                    <motion.div variants={objVariants} transition={{ duration: .9, delay: .15 }} initial='start' animate={motThree} ref={forThree}>
                        <button className='main-but'>
                            <div className="cover-but-two">
                                <span>կարդալ ավելին</span>
                            </div>
                        </button>
                    </motion.div>
                </div>
            </div>
            <div className="slider-part">
                <Swiper grabCursor={true} spaceBetween={40} slidesPerView={1.5} breakpoints={braker}>
                    <SwiperSlide>
                        <motion.div variants={{
                            play: { opacity: 0 },
                            opac: { opacity: 1 }
                        }} initial='play' animate={motPic} transition={{ duration: 1, delay: 0 }}>
                            <div className="cont">
                                <img src={img1} />
                            </div>
                        </motion.div>
                    </SwiperSlide>
                    <SwiperSlide>
                        <motion.div variants={{
                            play: { opacity: 0 },
                            opac: { opacity: 1 }
                        }} initial='play' animate={motPic} transition={{ duration: 1, delay: .5 }}>
                            <div className="cont">
                                <img src={img2} />
                            </div>
                        </motion.div>
                    </SwiperSlide>
                    <SwiperSlide>
                        <motion.div variants={{
                            play: { opacity: 0 },
                            opac: { opacity: 1 }
                        }} initial='play' animate={motPic} transition={{ duration: 1, delay: 1 }}>
                            <div className="cont">
                                <img src={img3} />
                            </div>
                        </motion.div>
                    </SwiperSlide>
                </Swiper>
            </div >
        </section >
    )
}
